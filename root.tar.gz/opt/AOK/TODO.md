# TODO

- Generating bzip2 images only results in very moderate size reductions
should be investigated to hopefully generate smaller images.
